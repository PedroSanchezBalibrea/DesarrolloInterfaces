﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;


namespace Ejercicio8_CuadrosTexto
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TextBox text;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Ayuda_KeyDown(object sender, KeyEventArgs e)
        {
            text = (TextBox)sender;

            if (text.Tag.ToString() == "nombre" && e.Key == Key.F1)
            {
                if (nombreTextBlock.Visibility == Visibility.Hidden) nombreTextBlock.Visibility = Visibility.Visible;
                else nombreTextBlock.Visibility = Visibility.Hidden;
            }
            else if (text.Tag.ToString() == "apellido" && e.Key == Key.F1)
            {
                if (apellidoTextBlock.Visibility == Visibility.Hidden) apellidoTextBlock.Visibility = Visibility.Visible;
                else apellidoTextBlock.Visibility = Visibility.Hidden;
            }
        }

        private void edadTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            text = (TextBox)sender;
            int i;

            if (e.Key == Key.F2 && !int.TryParse(text.Text,out i) && edadTextBlock.Visibility == Visibility.Hidden) edadTextBlock.Visibility = Visibility.Visible;
            else edadTextBlock.Visibility = Visibility.Hidden;
        }
    }
}
