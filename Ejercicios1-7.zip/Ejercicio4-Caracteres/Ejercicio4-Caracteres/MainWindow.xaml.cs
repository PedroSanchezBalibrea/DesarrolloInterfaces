﻿using System.Windows;
using System.Windows.Controls;

namespace Ejercicio4_Caracteres
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            numCaracteres.Content = texto.Text.Length + "/140";

            if (texto.Text.Length == 140) texto.IsReadOnly = true;
        }
    }
}
