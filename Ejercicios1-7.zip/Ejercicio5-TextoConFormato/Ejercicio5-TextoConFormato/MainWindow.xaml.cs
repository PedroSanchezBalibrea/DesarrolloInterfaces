﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ejercicio5_TextoConFormato
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            azulButton.IsChecked = true;
        }

        private void AzulRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            textoTextBlock.Foreground = Brushes.Blue;
        }

        private void RojoRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            textoTextBlock.Foreground = Brushes.Red;
        }

        private void VerdeRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            textoTextBlock.Foreground = Brushes.Green;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            textoTextBlock.Text = textoTextBox.Text;
        }

        private void cursivaButton_Checked(object sender, RoutedEventArgs e)
        {
            textoTextBlock.FontStyle = FontStyles.Italic;
        }

        private void negritaButton_Checked(object sender, RoutedEventArgs e)
        {
            textoTextBlock.FontWeight = FontWeights.Bold;
        }

        private void cursivaButton_Unchecked(object sender, RoutedEventArgs e)
        {
            textoTextBlock.FontStyle = FontStyles.Normal;
        }

        private void negritaButton_Unchecked(object sender, RoutedEventArgs e)
        {
            textoTextBlock.FontWeight = FontWeights.Normal;
        }
    }
}
