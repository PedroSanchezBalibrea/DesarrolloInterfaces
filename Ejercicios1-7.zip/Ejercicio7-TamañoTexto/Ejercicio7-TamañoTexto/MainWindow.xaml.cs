﻿using System.Windows;
using System.Windows.Controls;

namespace Ejercicio7_TamañoTexto
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = (RadioButton) sender;

            textoTextBlock.FontSize = double.Parse(radioButton.Tag.ToString());
        }
    }
}
