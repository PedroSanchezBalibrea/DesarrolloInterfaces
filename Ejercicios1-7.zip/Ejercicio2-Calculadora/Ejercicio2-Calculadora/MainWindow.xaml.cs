﻿using System;
using System.Windows;
using System.Windows.Controls;


namespace Ejercicio2_Calculadora
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        float operador1, operador2;

        public MainWindow()
        {
            InitializeComponent();
        }
        private void calcularButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                operador1 = float.Parse(operador1TextBox.Text);
                operador2 = float.Parse(operador2TextBox.Text);

                if (operacion1TextBox.Text == "+") resultadoTextBox.Text = "" + (operador1 + operador2);
                else if (operacion1TextBox.Text == "-") resultadoTextBox.Text = "" + (operador1 - operador2);
                else if (operacion1TextBox.Text == "*") resultadoTextBox.Text = "" + (operador1 * operador2);
                else if (operacion1TextBox.Text == "/" && operador1 != 0 && operador2 != 0) resultadoTextBox.Text = "" + (operador1 / operador2);
                else if (operacion1TextBox.Text == "/" && operador1 == 0 && operador2 == 0) resultadoTextBox.Text = "La nada entre la nada es igual a nada";

            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void limpiarButton_Click(object sender, RoutedEventArgs e)
        {
            operador1 = 0;
            operador2 = 0;
            operador1TextBox.Text = "";
            operador2TextBox.Text = "";
            resultadoTextBox.Text = "";
            operacion1TextBox.Text = "";
            calcularButton.IsEnabled = false;
        }
        private void operacion1TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (compruebaOperacion() && operador1TextBox.Text != "" && operador2TextBox.Text != "" && operacion1TextBox.Text != "") calcularButton.IsEnabled = true;
            else calcularButton.IsEnabled = false;
        }

        private bool compruebaOperacion()
        {
            if (operacion1TextBox.Text == "+" || operacion1TextBox.Text == "-" || operacion1TextBox.Text == "*" || operacion1TextBox.Text == "/") return true;
            else return false;
        }
    }
}
