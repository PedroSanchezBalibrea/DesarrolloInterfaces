﻿
using System.Windows;
using System.Windows.Controls;

namespace Ejercicio5_Calculadora
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            int cont = 0;
            Button[,] botones = new Button[3,3];

            for (int i = 0; i < botones.GetLength(0); i++)
            {

                for (int j = 0; j < botones.GetLength(1); j++)
                {
                    cont++;
                    Viewbox view = new Viewbox();
                    TextBlock numeros = new TextBlock();
                    if (cont <= 9) numeros.Text = cont.ToString();
                    else numeros.Text = "0";
                    view.Child = numeros;

                    botones[i, j] = new Button
                    {
                        Tag = cont
                    };
                    Grid.SetRow(botones[i, j], i);
                    Grid.SetColumn(botones[i, j], j);
                    
                    botones[i, j].Click += Button_Click;
                    botones[i, j].Content = view;
                    botonesButton.Children.Add(botones[i,j]);
                }
            }

            Viewbox viewCero = new Viewbox();
            TextBlock numeroCero = new TextBlock();

            numeroCero.Text = "0";
            viewCero.Child = numeroCero;

            Button boton = new Button
            {
                Tag = 0
            };
            Grid.SetRow(boton,4);
            Grid.SetColumn(boton, 0);
            Grid.SetColumnSpan(boton,3);
            boton.Click += Button_Click;
            boton.Content = viewCero;
            botonesButton.Children.Add(boton);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button boton = (Button)sender;

            calcTextBlock.Text += boton.Tag;
        }
    }
}
