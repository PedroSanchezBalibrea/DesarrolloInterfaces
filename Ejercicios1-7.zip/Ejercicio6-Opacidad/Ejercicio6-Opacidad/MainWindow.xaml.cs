﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;


namespace Ejercicio6_Opacidad
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void imgImage_MouseEnter(object sender, MouseEventArgs e)
        {
            Image imagen = (Image) sender;

            imagen.Opacity = 1;
        }

        private void imgImage_MouseLeave(object sender, MouseEventArgs e)
        {
            Image imagen = (Image)sender;

            imagen.Opacity = 0.5;
        }
    }
}
